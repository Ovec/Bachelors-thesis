#!/bin/bash
kubectl apply -k "../TOB1_cluster_installation/postgres"
