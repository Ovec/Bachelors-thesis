#!/bin/bash
kubectl apply -k ./cluster-old
