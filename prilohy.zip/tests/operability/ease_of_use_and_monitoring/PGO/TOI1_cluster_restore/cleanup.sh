#!/bin/bash
# Returns cluster to basic install
kubectl apply -k "../TOD1_cluster_installation/install"
