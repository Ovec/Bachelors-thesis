#!/bin/bash
# Returns cluster to basic install
kubectl apply -k ../TOB1_cluster_installation/postgres
