#!/bin/bash
kubectl apply -k ./postgres
