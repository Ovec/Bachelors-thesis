#!/bin/bash
kubectl delete -k ./postgres
