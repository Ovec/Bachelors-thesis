#!/bin/bash
kubectl delete -k ../TOB1_cluster_installation/install
