#!/bin/bash
kubectl delete -k ../TOA1_operator_installation/install
