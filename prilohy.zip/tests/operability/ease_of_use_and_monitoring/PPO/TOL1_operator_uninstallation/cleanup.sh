#!/bin/bash
kubectl apply -k ../TOA1_operator_installation/install
