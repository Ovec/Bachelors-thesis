#!/bin/bash
kubectl delete -k install
kubectl delete namespace pgo
