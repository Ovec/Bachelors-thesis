#!/bin/bash
helm uninstall stackgres-operator --namespace stackgres
