#!/bin/bash
kubectl apply -f ../TOA1_operator_installation/install/install.yaml
