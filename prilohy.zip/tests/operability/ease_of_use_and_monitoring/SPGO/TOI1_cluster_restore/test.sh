#!/bin/bash
# Backup created in UI
kubectl apply -k ./patch
