#!/bin/bash
kubectl delete -k ./patch
