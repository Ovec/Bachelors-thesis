#!/bin/bash
kubectl apply -k ./patch_14_7
