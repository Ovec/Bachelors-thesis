#!/bin/bash
kubectl apply -k ./patch
