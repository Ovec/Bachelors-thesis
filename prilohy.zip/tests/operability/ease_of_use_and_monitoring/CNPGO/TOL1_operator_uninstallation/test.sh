#!/bin/bash
kubectl delete -f ../TOA1_operator_installation/install/install.yaml
