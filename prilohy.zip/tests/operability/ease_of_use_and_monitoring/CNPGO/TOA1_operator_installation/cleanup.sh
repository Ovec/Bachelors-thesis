#!/bin/bash
kubectl delete -f install/install.yaml
