#!/bin/bash
kubectl apply -f install/install.yaml
