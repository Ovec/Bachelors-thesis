#!/bin/bash
kubectl apply -k ./pooler
