#!/bin/bash
kubectl delete -k ./pooler
