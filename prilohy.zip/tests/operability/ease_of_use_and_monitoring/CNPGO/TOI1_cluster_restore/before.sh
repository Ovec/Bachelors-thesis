kubectl create secret generic backup-creds --from-file=gcsCredentials=../../operators-385815-008a03a2fd73.json -ns postgres-operator
